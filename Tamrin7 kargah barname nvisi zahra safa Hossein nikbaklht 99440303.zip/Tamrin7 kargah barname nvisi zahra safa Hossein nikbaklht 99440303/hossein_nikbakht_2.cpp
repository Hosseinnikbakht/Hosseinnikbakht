#include <iostream>
using namespace std;
//hossein_nikbakht
int fibo(int number);

int main(int argc, char** argv)
{
    int n;
    cout<<"Enter n: ";
    cin>>n;
    cout<<"fibonacci "<<n<<" = "<<fibo(n-1)<<endl;
    return 0;
}

int fibo(int number){
    if( number == 1 || number == 0){
        return 1;
    }
    else{
    return fibo(number-1) + fibo(number-2);
    }
}
