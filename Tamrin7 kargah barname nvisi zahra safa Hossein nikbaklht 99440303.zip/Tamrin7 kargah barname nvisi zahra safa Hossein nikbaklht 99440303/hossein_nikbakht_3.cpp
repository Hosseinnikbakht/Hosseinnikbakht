#include <iostream>
using namespace std;
//hossein_nikbakht

int binarySearch(int arr[], int h, int r, int x) 
{ 
    if (r >= h) { 
        int mid = h + (r - h) / 2; 
        if (arr[mid] == x) 
            return mid; 
  
        if (arr[mid] > x) 
            return binarySearch(arr, h, mid - 1, x); 
        return binarySearch(arr, mid + 1, r, x);
    } 
    return -1; 
} 
  
int main(int argc, char** argv) 
{ 
    int arr[20],n,x; 
    cout<<"Enter the size of the array :";
    cin>>n;
    for(int i=0;i<n;i++){
    	cout<<"Enter number: ";
    	cin>>arr[i];
    }
    while(true){
 	   int flag=1;
     	for(int i=0;i<n-1;i++){
    	 	if(arr[i]>arr[i+1]){
     			int temp=arr[i];
     			arr[i]=arr[i+1];
  	   		arr[i+1]=temp;
  	   		flag=0;
 	    	}
  	  }
  	  if(flag)
  	  	break;
    }
    cout<<"_______________"<<endl;
    for(int i=0;i<n;i++){
    	cout<<"number in index "<<i<<" = "<<arr[i]<<endl;
    }
    cout<<"_______________"<<endl;
    cout<<"Enter number for search: ";
    cin>>x;
    int result = binarySearch(arr, 0, n , x);
    
    if(result == -1)
    	cout << "Element is not present in array";
     else 
	 	cout << "Element is present at index " << result; 
    return 0; 
}
